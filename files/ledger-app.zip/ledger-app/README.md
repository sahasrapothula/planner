# Ledger — Daily Planner

A brain-dump + day-kanban planner + drag-to-timebox calendar app, installable as a PWA.

## Fastest way to use it right now
Just double-click `index.html` — it opens in your browser and works fully offline.
Note: opened this way, your data is tied to that browser on that machine only.

## Turn it into a real installable app (recommended)
This needs to be served over http/https (not opened as a raw file) for the "Install app" /
"Add to Home Screen" prompt and offline caching to work. Free options, ~2 minutes each:

### Option A — GitHub Pages (free, permanent URL)
1. Create a new GitHub repo (e.g. `ledger-planner`).
2. Upload all 4 files in this folder (`index.html`, `manifest.json`, `service-worker.js`,
   `icon-192.png`, `icon-512.png`) to the repo root.
3. Repo → Settings → Pages → Source: `main` branch, `/ (root)` → Save.
4. Your app is live at `https://<your-username>.github.io/ledger-planner/` within a minute.
5. Open that URL on your phone → Share/Menu → "Add to Home Screen." On desktop Chrome,
   click the install icon (⊕) in the address bar.

### Option B — Netlify Drop (free, no account needed for a quick link)
1. Go to https://app.netlify.com/drop
2. Drag this whole folder onto the page.
3. You get an instant `https://something.netlify.app` URL — same install steps as above.

## About your data
Tasks are stored in the browser's local storage on whichever device/browser you use the
app in — nothing is sent to a server. That means:
- Fast, private, works offline.
- Data does **not** sync between your phone and laptop automatically (each install is
  its own local copy). If you want cross-device sync later, that requires adding a small
  backend or a sync service (e.g. Supabase) — say the word if you want that built in.

## Files
- `index.html` — the entire app (HTML/CSS/JS, single file)
- `manifest.json` — PWA metadata (name, icons, colors) for "install as app"
- `service-worker.js` — enables offline use after the first load
- `icon-192.png` / `icon-512.png` — app icons
